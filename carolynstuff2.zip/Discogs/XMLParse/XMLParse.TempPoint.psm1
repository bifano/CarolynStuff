﻿<#	
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2016 v5.2.124
	 Created on:   	12/22/2016 8:07 PM
	 Created by:   	carol
	 Organization: 	
	 Filename:     	XMLParse.psm1
	-------------------------------------------------------------------------
	 Module Name: XMLParse
	===========================================================================
#>

function Write-HelloWorld
{
	Write-Host "Hello World"
}

Export-ModuleMember Write-HelloWorld



