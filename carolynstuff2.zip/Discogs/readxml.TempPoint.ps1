﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2016 v5.2.124
	 Created on:   	12/22/2016 8:17 PM
	 Created by:   	carol
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Import-Module 'd:\Downloads\Xml Module 6.6.ps1'
#$filename = "D:\Downloads\discogs_20161201_releases.xml\discogs_20161201_releases.xml"

#$xmlDoc = [System.Xml.XmlDocument](Get-Content $fileName);
#$xmlDoc = (Select-Xml -Path $fileName -XPath /).Node