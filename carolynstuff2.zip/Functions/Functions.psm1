﻿<#	
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2016 v5.2.124
	 Created on:   	12/28/2016 10:26 PM
	 Created by:   	carol
	 Organization: 	
	 Filename:     	Functions.psm1
	-------------------------------------------------------------------------
	 Module Name: Functions
	===========================================================================
#>

function Write-HelloWorld
{
	Write-Host "Hello World"
}

Export-ModuleMember Write-HelloWorld



