﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2016 v5.2.124
	 Created on:   	12/28/2016 10:26 PM
	 Created by:   	carol
	 Organization: 	
	 Filename:     	UnlockFiles.ps1
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
